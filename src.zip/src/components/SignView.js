import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./SignView.css";


export default function SignView() {
    let [sign, setSign] = useState("");
    let [date, setDate] = useState("");
    let [horoscope, setHoroscope] = useState("");
    let [error, setError] = useState("");

function handleSubmit(event) {
        event.preventDefault();
        fetch(`https://aztro.sameerkumar.website/?sign=${sign}&day=${date}`)
            .then((response) => response.json())
            .then((data) => {
                if (data.error) {
                    setError(data.error);
                } else {
                    setError("");
                    setHoroscope(data.description);
                }
            });
    }  

    
    return (
        <div className="SignView">
            <h1>Horoscope</h1>
            <form onSubmit={handleSubmit}>
                <label htmlFor="sign">Sign</label>
                <select
                    id="sign"
                    value={sign}
                    onChange={(event) => setSign(event.target.value)}
                >
                    <option value="">--Please choose an option--</option>
                    <option value="aries">Aries</option>
                    <option value="taurus">Taurus</option>
                    <option value="gemini">Gemini</option>
                    <option value="cancer">Cancer</option>
                    <option value="leo">Leo</option>
                    <option value="virgo">Virgo</option>
                    <option value="libra">Libra</option>
                    <option value="scorpio">Scorpio</option>
                    <option value="sagittarius">Sagittarius</option>
                    <option value="capricorn">Capricorn</option>
                    <option value="aquarius">Aquarius</option>
                    <option value="pisces">Pisces</option>
 </select>
  </form>
    <form onSubmit={handleSubmit}> 
                <label htmlFor="date">Date</label>
                <select
                    id="date"
                    value={date}
                    onChange={(event) => setDate(event.target.value)}
                >
                    <option value="">--Please choose an option--</option>
                    <option value="today">Today</option>
                    <option value="tomorrow">Tomorrow</option>
                </select>
                <button type="submit">Submit</button>
            </form>
            <p>{error}</p>
            <p>{horoscope}</p>
            <Link to="/">Home</Link>
            <Link to="/about">About</Link>
        </div>
    );
}


                        
