export default [
    {
      "id": 1,
      "answer": "It is certain",
    },
    {
      "id": 2,
      "answer":"Without a doubt",
    },
  
    {
      "id": 3,
      "answer":"You may rely on it",
    }
    ,
    {
      "id": 4,
      "answer":"It is decidedly so",
    },
    {
        "id": 5,
        "answer":"Yes, definitely",
    },
    {
        "id": 6,
        "answer":"The stars are aligned",
    },
    {
        "id": 7,
        "answer":"The vibes are good!",
    },
    {
       "id": 8,
       "answer":"Signs point to yes",
    },
    {
      "id": 9,
      "answer":"The outcome is better than you could have imagined",
   },


       {
        "id": 10,
        "answer":"The signs are hazy, focus and try again",
         },

    
    {   
        "id": 11,
        "answer":"The vibrations are good",
    },

    {
        "id": 12,
        "answer":"Trust your gut, it's usually right",
    },

    {   
        "id": 13,
        "answer":"There's something you're not seeing, try again",
    },

    {
        "id": 14,
        "answer":"You know the answer, trust yourself",
    },

    {
        "id": 15,
        "answer":"Concentrate and ask again",
    },

    {
        "id": 16,
        "answer":"Don't count on it",
    },

    {
        "id": 17,
        "answer":"There's a fork in the road, choose wisely",
    },

    {
        "id": 18,
        "answer":"The signs point to no",
    },

    {
        "id": 19,
        "answer":"The vibes are off, try again",
    },

    {
        "id": 20,
        "answer":"The stars are not aligned",
    },

    {
        "id": 21,
        "answer":"The outcome is not what you hoped for",
    },

    {
        "id": 22,
        "answer":"If you really want it, you'll find a way",
    },

    {
        "id": 23,
        "answer":"The answer was shown to you, but you didn't see it",
    },




    ]